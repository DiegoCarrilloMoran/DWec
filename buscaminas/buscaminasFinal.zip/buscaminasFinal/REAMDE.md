el script esta pensado por mi y hecho por mi
parti de la base de un html de una buscmainas ya hecho para estructurar mi idea https://github.com/javimontoto/Buscaminas
aqui esta mi fuente, el js es basntante disintinto al mio en funcionamiento
el css esta hecho casi integramente por chat gpt solo para hacerlo mas estetico